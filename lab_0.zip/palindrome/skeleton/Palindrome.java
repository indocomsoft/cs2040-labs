/*
 * author		: []
 * matric no.	: []
 */

import java.util.*;

public class Palindrome {
	/* use this method to check whether the string is palindrome word or not
	 * 		PRE-Condition  :
	 * 		POST-Condition :
	 */
	public static boolean isPalindrome(String word) {

	}
	
	public static void main(String[] args) {
		// declare the necessary variables


		// declare a Scanner object to read input


		// read input and process them accordingly


		// simulate the problem


		// output the result

	}
}