/**
 * Name         :
 * Matric No.   :
 * PLab Acct.   :
 */

import java.util.*;

class Modulo {
    private int value;      //To store the value of the number, must be non-negative and less than the modulus
    private int modulus;    //To store the modulus of the Modulo
    
    // Add more attributes, constructor and methods here if required
    
    /**
     * Constructor class for Modulo
     * Pre-condition: Modulus cannot be zero and value cannot be negative
     */
    Modulo (int value, int modulus) {
        if (modulus == 0) {
            throw new IllegalArgumentException("Modulus cannot be zero.");
        }
        this.value = value % modulus;
        this.modulus = modulus;
    }
    
    /**
     * Returns the value of the Modulo value
     */
    public int getValue(){
        return value;
    }
    
    /**
     * Adds two Modulo values and returns a new Modulo value as a result
     * Pre-condition: Modulus must be the same
     */
    public Modulo plus(Modulo other) {
        if (modulus != other.modulus) {
            throw new IllegalArgumentException("Modulus do not match.");
        }
        //Write code here
        
        return new Modulo(0, 1);    
    }
    
    /**
     * Subtracts two Modulo values and returns a new Modulo value as a result
     * Pre-condition: Modulus must be the same
     */
    public Modulo minus(Modulo other) {
        if (modulus != other.modulus) {
            throw new IllegalArgumentException("Modulus do not match.");
        }
        //Write code here
        
        return new Modulo(0, 1);    
    }
    
    /**
     * Multiples two Modulo values and returns a new Modulo value as a result
     * Pre-condition: Modulus must be the same
     */
    public Modulo times(Modulo other) {
        if (modulus != other.modulus) {
            throw new IllegalArgumentException("Modulus do not match.");
        }
        //Write code here
        
        return new Modulo(0, 1);      
    }
    
    
    /**
     * Divides two Modulo values and returns a new Modulo value as a result
     * Pre-condition: Modulus must be the same and division must be valid
     */
    public Modulo divide(Modulo other) {
        if (modulus != other.modulus) {
            throw new IllegalArgumentException("Modulus do not match.");
        }
        //Write code here
        
        return new Modulo(0, 1);      
    }
    
    /**
     * Find modular inverse of the Modulo value
     * Pre-condition: Inverse must exist
     */
    public Modulo findInverse() {
        int xx = 0;
        int x = 1;
        int yy = 1;
        int y = 0;
        int a = this.value;
        int b = this.modulus;
        while (b > 0) {
            int q = a / b;
            int t = b; 
            b = a % b; 
            a = t;
            t = xx; 
            xx = x - q * xx; 
            x = t;
            t = yy;
            yy = y - q * yy; 
            y = t;
        }
        if (a > 1) {
            throw new ArithmeticException("Inverse does not exist.");
        } else {
            return new Modulo((x + this.modulus) % this.modulus, this.modulus);
        }
    }
}

public class ModuloTester {
    
    public static void main(String[] args) {
        //Write code here
    }
}